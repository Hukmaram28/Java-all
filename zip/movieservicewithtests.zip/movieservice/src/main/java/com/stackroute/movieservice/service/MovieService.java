package com.stackroute.movieservice.service;

import com.stackroute.movieservice.domain.Movie;
import com.stackroute.movieservice.exceptions.MovieAlreadyExistsException;
import com.stackroute.movieservice.exceptions.MovieNotFoundException;

import java.util.List;

public interface MovieService {
     Movie saveMovie(Movie movie) throws MovieAlreadyExistsException;
     List<Movie> getAllMovies();
     Movie getMovie(int id) throws MovieNotFoundException;
     List<Movie> findMovieByName(String movieName);
     void deleteMovie(int id)throws MovieNotFoundException;
     void updateMovie(Movie movie, int id) throws MovieNotFoundException;

}
